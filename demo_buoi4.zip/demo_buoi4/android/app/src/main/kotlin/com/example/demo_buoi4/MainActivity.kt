package com.example.demo_buoi4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
